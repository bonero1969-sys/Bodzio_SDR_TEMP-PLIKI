/**
  ******************************************************************************
  * @file    usb.h
  * @brief   Consolidated USB Device Library core + AUDIO 1.0 class driver.
  *          Merges usbd_core_ex, usbd_ctlreq, usbd_ioreq and usbd_audio into a
  *          single translation unit to keep the USB stack in one library.
  ******************************************************************************
  */
#ifndef __USB_H
#define __USB_H

#include "usbd_core.h"
#include "usbd_ctlreq.h"
#include "usbd_ioreq.h"
#include "usbd_audio.h"

#endif /* __USB_H */
