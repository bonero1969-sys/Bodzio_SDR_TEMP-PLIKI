#!/usr/bin/env python3
"""Generate Keil MDK-ARM .uvprojx / .uvoptx for STM32H743ZI USB Audio mic.

Produces a CANONICAL .uvprojx (SchemaVersion 2.1, TargetArmAds wrapper)
matching the structure of a real CubeMX-exported MDK project, so Keil fully
honors the Cads IncludePath and defines.
"""
import os, glob

ROOT = "/home/user/workspace/STM32H743ZI_USB_Audio_Mic"
MDK  = os.path.join(ROOT, "MDK-ARM")

def rel(p):
    return os.path.relpath(p, MDK).replace("\\", "/")

# --- File groups (path -> list of absolute files) ---
groups = []

app_src = os.path.join(ROOT, "Application/Src")
groups.append(("Application/User", [
    os.path.join(app_src, "main.c"),
    os.path.join(app_src, "stm32h7xx_it.c"),
    os.path.join(app_src, "stm32h7xx_hal_msp.c"),
    os.path.join(app_src, "usbd_conf.c"),
    os.path.join(app_src, "usbd_desc.c"),
    os.path.join(app_src, "audio_sine_source.c"),
]))

# HAL driver — only the modules this project actually needs (keeps compile
# time minimal; ~14 files instead of ~125).
hal_src = os.path.join(ROOT, "Drivers/STM32H7xx_HAL_Driver/Src")
hal_files = [
    "stm32h7xx_hal.c",
    "stm32h7xx_hal_cortex.c",
    "stm32h7xx_hal_rcc.c",
    "stm32h7xx_hal_rcc_ex.c",
    "stm32h7xx_hal_pwr.c",
    "stm32h7xx_hal_pwr_ex.c",
    "stm32h7xx_hal_gpio.c",
    "stm32h7xx_hal_dma.c",
    "stm32h7xx_hal_dma_ex.c",
    "stm32h7xx_hal_mdma.c",
    "stm32h7xx_hal_hsem.c",
    "stm32h7xx_hal_pcd.c",
    "stm32h7xx_hal_pcd_ex.c",
    "stm32h7xx_ll_usb.c",
]
hal_files = [os.path.join(hal_src, f) for f in hal_files]
groups.append(("Drivers/STM32H7xx_HAL_Driver", hal_files))

groups.append(("Drivers/CMSIS", [
    os.path.join(ROOT, "Drivers/CMSIS/Device/ST/STM32H7xx/Source/Templates/system_stm32h7xx.c"),
]))

groups.append(("MDK-ARM/startup", [
    os.path.join(MDK, "startup_stm32h743xx.s"),
]))

# USB Device Library Core + AUDIO 1.0 class — consolidated into usb.c/usb.h
usb_stack = os.path.join(ROOT, "Middlewares/ST/USB_Stack")
groups.append(("Middlewares/USB_Stack", [
    os.path.join(usb_stack, "usb.c"),
]))

str_src = os.path.join(ROOT, "Middlewares/ST/AUDIO_Streaming/Src")
groups.append(("Middlewares/AUDIO_Streaming", [
    os.path.join(str_src, "audio_usb_nodes.c"),
    os.path.join(str_src, "audio_usb_recording_session.c"),
    os.path.join(str_src, "usbd_audio_10_config_descriptors.c"),
    os.path.join(str_src, "usbd_audio_if.c"),
    os.path.join(str_src, "audio_dummymic_node.c"),
]))

# --- Include paths ---
inc_paths = [
    "../Application/Inc",
    "../Drivers/STM32H7xx_HAL_Driver/Inc",
    "../Drivers/STM32H7xx_HAL_Driver/Inc/Legacy",
    "../Drivers/CMSIS/Include",
    "../Drivers/CMSIS/Device/ST/STM32H7xx/Include",
    "../Middlewares/ST/STM32_USB_Device_Library/Core/Inc",
    "../Middlewares/ST/STM32_USB_Device_Library/Class/AUDIO_10/Inc",
    "../Middlewares/ST/AUDIO_Streaming/Inc",
    "../Middlewares/ST/USB_Stack",
]
inc_str = ";".join(inc_paths)

defines = "USE_HAL_DRIVER,STM32H743xx,USE_USB_FS,USE_USB_AUDIO_CLASS_10=1,USE_USB_AUDIO_RECORDING=1,USE_USB_AUDIO_PLAYBACK=0,USE_AUDIO_DUMMY_MIC=1"

# --- Build groups XML ---
def file_xml(path):
    ext = path.split(".")[-1].lower()
    ftype = "1" if ext in ("c", "cpp") else ("2" if ext == "s" else "5")
    return (f'            <File>\n'
            f'              <FileName>{os.path.basename(path)}</FileName>\n'
            f'              <FileType>{ftype}</FileType>\n'
            f'              <FilePath>{rel(path)}</FilePath>\n'
            f'            </File>')

groups_xml = ""
for name, files in groups:
    groups_xml += (f'        <Group>\n'
                   f'          <GroupName>{name}</GroupName>\n'
                   f'          <Files>\n')
    for f in files:
        groups_xml += file_xml(f) + "\n"
    groups_xml += '          </Files>\n        </Group>\n'

total_files = sum(len(f) for _, f in groups)

# --- Canonical .uvprojx (SchemaVersion 2.1, TargetArmAds) ---
proj = f'''<?xml version="1.0" encoding="UTF-8" standalone="no" ?>
<Project xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="project_projx.xsd">

  <SchemaVersion>2.1</SchemaVersion>

  <Header>### uVision Project, (C) Keil Software</Header>

  <Targets>
    <Target>
      <TargetName>STM32H743ZI_USB_Audio_Mic</TargetName>
      <ToolsetNumber>0x4</ToolsetNumber>
      <ToolsetName>ARM-ADS</ToolsetName>
      <pCCUsed>5060528::V5.06 update 5 (build 528)::ARMCC</pCCUsed>
      <uAC6>0</uAC6>
      <TargetOption>
        <TargetCommonOption>
          <Device>STM32H743ZITx</Device>
          <Vendor>STMicroelectronics</Vendor>
          <PackID>Keil.STM32H7xx_DFP.3.0.0</PackID>
          <PackURL>http://www.keil.com/pack</PackURL>
          <Cpu>IROM(0x08000000-0x081FFFFF) IRAM(0x20000000-0x2001FFFF) IRAM2(0x24000000-0x2403FFFF) CLOCK(240000000) FPU3(DFPU) CPUTYPE("Cortex-M7") ELITTLE</Cpu>
          <FlashUtilSpec></FlashUtilSpec>
          <StartupFile></StartupFile>
          <FlashDriverDll></FlashDriverDll>
          <DeviceId></DeviceId>
          <RegisterFile></RegisterFile>
          <MemoryEnv></MemoryEnv>
          <Cmp></Cmp>
          <Asm></Asm>
          <Linker></Linker>
          <OHString></OHString>
          <InfinionOptionDll></InfinionOptionDll>
          <SLE66CMisc></SLE66CMisc>
          <SLE66AMisc></SLE66AMisc>
          <SLE66LinkerMisc></SLE66LinkerMisc>
          <SFDFile>$$Device:STM32H743ZITx$CMSIS\\SVD\\STM32H7x3.svd</SFDFile>
          <bCustSvd>0</bCustSvd>
          <UseEnv>0</UseEnv>
          <BinPath></BinPath>
          <IncludePath></IncludePath>
          <LibPath></LibPath>
          <RegisterFilePath></RegisterFilePath>
          <DBRegisterFilePath></DBRegisterFilePath>
          <TargetStatus>
            <Error>0</Error>
            <ExitCodeStop>0</ExitCodeStop>
            <ButtonStop>0</ButtonStop>
            <NotGenerated>0</NotGenerated>
            <InvalidFlash>1</InvalidFlash>
          </TargetStatus>
          <OutputDirectory>Output\\</OutputDirectory>
          <OutputName>STM32H743ZI_USB_Audio_Mic</OutputName>
          <CreateExecutable>1</CreateExecutable>
          <CreateLib>0</CreateLib>
          <CreateHexFile>1</CreateHexFile>
          <DebugInformation>1</DebugInformation>
          <BrowseInformation>1</BrowseInformation>
          <ListingPath></ListingPath>
          <HexFormatSelection>1</HexFormatSelection>
          <Merge32K>0</Merge32K>
          <CreateBatchFile>0</CreateBatchFile>
          <BeforeCompile>
            <RunUserProg1>0</RunUserProg1>
            <RunUserProg2>0</RunUserProg2>
            <UserProg1Name></UserProg1Name>
            <UserProg2Name></UserProg2Name>
            <UserProg1Dos16Mode>0</UserProg1Dos16Mode>
            <UserProg2Dos16Mode>0</UserProg2Dos16Mode>
            <nStopU1X>0</nStopU1X>
            <nStopU2X>0</nStopU2X>
          </BeforeCompile>
          <BeforeMake>
            <RunUserProg1>0</RunUserProg1>
            <RunUserProg2>0</RunUserProg2>
            <UserProg1Name></UserProg1Name>
            <UserProg2Name></UserProg2Name>
            <UserProg1Dos16Mode>0</UserProg1Dos16Mode>
            <UserProg2Dos16Mode>0</UserProg2Dos16Mode>
            <nStopB1X>0</nStopB1X>
            <nStopB2X>0</nStopB2X>
          </BeforeMake>
          <AfterMake>
            <RunUserProg1>0</RunUserProg1>
            <RunUserProg2>0</RunUserProg2>
            <UserProg1Name></UserProg1Name>
            <UserProg2Name></UserProg2Name>
            <UserProg1Dos16Mode>0</UserProg1Dos16Mode>
            <UserProg2Dos16Mode>0</UserProg2Dos16Mode>
            <nStopA1X>0</nStopA1X>
            <nStopA2X>0</nStopA2X>
          </AfterMake>
          <SelectedForBatchBuild>0</SelectedForBatchBuild>
          <SVCSIdString></SVCSIdString>
        </TargetCommonOption>
        <CommonProperty>
          <UseCPPCompiler>0</UseCPPCompiler>
          <RVCTCodeConst>0</RVCTCodeConst>
          <RVCTZI>0</RVCTZI>
          <RVCTOtherData>0</RVCTOtherData>
          <ModuleSelection>0</ModuleSelection>
          <IncludeInBuild>1</IncludeInBuild>
          <AlwaysBuild>0</AlwaysBuild>
          <GenerateAssemblyFile>0</GenerateAssemblyFile>
          <AssembleAssemblyFile>0</AssembleAssemblyFile>
          <PublicsOnly>0</PublicsOnly>
          <StopOnExitCode>3</StopOnExitCode>
          <CustomArgument></CustomArgument>
          <IncludeLibraryModules></IncludeLibraryModules>
          <ComprImg>0</ComprImg>
        </CommonProperty>
        <DllOption>
          <SimDllName>SARMCM3.DLL</SimDllName>
          <SimDllArguments>-REMAP -MPU</SimDllArguments>
          <SimDlgDll>DCM.DLL</SimDlgDll>
          <SimDlgDllArguments>-pCM7</SimDlgDllArguments>
          <TargetDllName>SARMCM3.DLL</TargetDllName>
          <TargetDllArguments>-MPU</TargetDllArguments>
          <TargetDlgDll>TCM.DLL</TargetDlgDll>
          <TargetDlgDllArguments>-pCM7</TargetDlgDllArguments>
        </DllOption>
        <DebugOption>
          <OPTHX>
            <HexSelection>1</HexSelection>
            <HexRangeLowAddress>0</HexRangeLowAddress>
            <HexRangeHighAddress>0</HexRangeHighAddress>
            <HexOffset>0</HexOffset>
            <Oh166RecLen>16</Oh166RecLen>
          </OPTHX>
        </DebugOption>
        <Utilities>
          <Flash1>
            <UseTargetDll>1</UseTargetDll>
            <UseExternalTool>0</UseExternalTool>
            <RunIndependent>0</RunIndependent>
            <UpdateFlashBeforeDebugging>1</UpdateFlashBeforeDebugging>
            <Capability>1</Capability>
            <DriverSelection>4107</DriverSelection>
          </Flash1>
          <bUseTDR>1</bUseTDR>
          <Flash2>STLink\\ST-LINKIII-KEIL_SWO.dll</Flash2>
          <Flash3></Flash3>
          <Flash4></Flash4>
          <pFcarmOut></pFcarmOut>
          <pFcarmGrp></pFcarmGrp>
          <pFcArmRoot></pFcArmRoot>
          <FcArmLst>0</FcArmLst>
        </Utilities>
        <TargetArmAds>
          <ArmAdsMisc>
            <GenerateListings>0</GenerateListings>
            <asHll>1</asHll>
            <asAsm>1</asAsm>
            <asMacX>1</asMacX>
            <asSyms>1</asSyms>
            <asFals>1</asFals>
            <asDbgD>1</asDbgD>
            <asForm>1</asForm>
            <ldLst>0</ldLst>
            <ldmm>1</ldmm>
            <ldXref>1</ldXref>
            <BigEnd>0</BigEnd>
            <AdsALst>1</AdsALst>
            <AdsACrf>1</AdsACrf>
            <AdsANop>0</AdsANop>
            <AdsANot>0</AdsANot>
            <AdsLLst>1</AdsLLst>
            <AdsLmap>1</AdsLmap>
            <AdsLcgr>1</AdsLcgr>
            <AdsLsym>1</AdsLsym>
            <AdsLszi>1</AdsLszi>
            <AdsLtoi>1</AdsLtoi>
            <AdsLsun>1</AdsLsun>
            <AdsLven>1</AdsLven>
            <AdsLsxf>1</AdsLsxf>
            <RvctClst>0</RvctClst>
            <GenPPlst>0</GenPPlst>
            <AdsCpuType>"Cortex-M7"</AdsCpuType>
            <RvctDeviceName></RvctDeviceName>
            <mOS>0</mOS>
            <uocRom>0</uocRom>
            <uocRam>0</uocRam>
            <hadIROM>1</hadIROM>
            <hadIRAM>1</hadIRAM>
            <hadXRAM>0</hadXRAM>
            <uocXRam>0</uocXRam>
            <RvdsVP>3</RvdsVP>
            <RvdsMve>0</RvdsMve>
            <hadIRAM2>1</hadIRAM2>
            <hadIROM2>0</hadIROM2>
            <StupSel>8</StupSel>
            <useUlib>0</useUlib>
            <EndSel>0</EndSel>
            <uLtcg>0</uLtcg>
            <nSecure>0</nSecure>
            <RoSelD>3</RoSelD>
            <RwSelD>3</RwSelD>
            <CodeSel>0</CodeSel>
            <OptFeed>0</OptFeed>
            <NoZi1>0</NoZi1>
            <NoZi2>0</NoZi2>
            <NoZi3>0</NoZi3>
            <NoZi4>0</NoZi4>
            <NoZi5>0</NoZi5>
            <Ro1Chk>0</Ro1Chk>
            <Ro2Chk>0</Ro2Chk>
            <Ro3Chk>0</Ro3Chk>
            <Ir1Chk>1</Ir1Chk>
            <Ir2Chk>0</Ir2Chk>
            <Ra1Chk>0</Ra1Chk>
            <Ra2Chk>0</Ra2Chk>
            <Ra3Chk>0</Ra3Chk>
            <Im1Chk>1</Im1Chk>
            <Im2Chk>0</Im2Chk>
            <OnChipMemories>
              <Ocm1><Type>0</Type><StartAddress>0x0</StartAddress><Size>0x0</Size></Ocm1>
              <Ocm2><Type>0</Type><StartAddress>0x0</StartAddress><Size>0x0</Size></Ocm2>
              <Ocm3><Type>0</Type><StartAddress>0x0</StartAddress><Size>0x0</Size></Ocm3>
              <Ocm4><Type>0</Type><StartAddress>0x0</StartAddress><Size>0x0</Size></Ocm4>
              <Ocm5><Type>0</Type><StartAddress>0x0</StartAddress><Size>0x0</Size></Ocm5>
              <Ocm6><Type>0</Type><StartAddress>0x0</StartAddress><Size>0x0</Size></Ocm6>
              <IRAM><Type>0</Type><StartAddress>0x20000000</StartAddress><Size>0x20000</Size></IRAM>
              <IROM><Type>1</Type><StartAddress>0x8000000</StartAddress><Size>0x200000</Size></IROM>
              <XRAM><Type>0</Type><StartAddress>0x0</StartAddress><Size>0x0</Size></XRAM>
              <OCR_RVCT1><Type>1</Type><StartAddress>0x0</StartAddress><Size>0x0</Size></OCR_RVCT1>
              <OCR_RVCT2><Type>1</Type><StartAddress>0x0</StartAddress><Size>0x0</Size></OCR_RVCT2>
              <OCR_RVCT3><Type>1</Type><StartAddress>0x0</StartAddress><Size>0x0</Size></OCR_RVCT3>
              <OCR_RVCT4><Type>1</Type><StartAddress>0x8000000</StartAddress><Size>0x200000</Size></OCR_RVCT4>
              <OCR_RVCT5><Type>1</Type><StartAddress>0x0</StartAddress><Size>0x0</Size></OCR_RVCT5>
              <OCR_RVCT6><Type>0</Type><StartAddress>0x0</StartAddress><Size>0x0</Size></OCR_RVCT6>
              <OCR_RVCT7><Type>0</Type><StartAddress>0x0</StartAddress><Size>0x0</Size></OCR_RVCT7>
              <OCR_RVCT8><Type>0</Type><StartAddress>0x0</StartAddress><Size>0x0</Size></OCR_RVCT8>
              <OCR_RVCT9><Type>0</Type><StartAddress>0x20000000</StartAddress><Size>0x20000</Size></OCR_RVCT9>
              <OCR_RVCT10><Type>0</Type><StartAddress>0x0</StartAddress><Size>0x0</Size></OCR_RVCT10>
            </OnChipMemories>
            <RvctStartVector></RvctStartVector>
          </ArmAdsMisc>
          <Cads>
            <interw>1</interw>
            <Optim>1</Optim>
            <oTime>0</oTime>
            <SplitLS>0</SplitLS>
            <OneElfS>1</OneElfS>
            <Strict>0</Strict>
            <EnumInt>0</EnumInt>
            <PlainCh>0</PlainCh>
            <Ropi>0</Ropi>
            <Rwpi>0</Rwpi>
            <wLevel>3</wLevel>
            <uThumb>0</uThumb>
            <uSurpInc>0</uSurpInc>
            <uC99>1</uC99>
            <uGnu>1</uGnu>
            <useXO>0</useXO>
            <v6Lang>0</v6Lang>
            <v6LangP>0</v6LangP>
            <vShortEn>1</vShortEn>
            <vShortWch>1</vShortWch>
            <v6Lto>0</v6Lto>
            <v6WtE>0</v6WtE>
            <v6Rtti>0</v6Rtti>
            <VariousControls>
              <MiscControls></MiscControls>
              <Define>{defines}</Define>
              <Undefine></Undefine>
              <IncludePath>{inc_str}</IncludePath>
            </VariousControls>
          </Cads>
          <Aads>
            <interw>1</interw>
            <Ropi>0</Ropi>
            <Rwpi>0</Rwpi>
            <thumb>0</thumb>
            <SplitLS>0</SplitLS>
            <SwStkChk>0</SwStkChk>
            <NoWarn>0</NoWarn>
            <uSurpInc>0</uSurpInc>
            <useXO>0</useXO>
            <uClangAs>0</uClangAs>
            <VariousControls>
              <MiscControls></MiscControls>
              <Define></Define>
              <Undefine></Undefine>
              <IncludePath></IncludePath>
            </VariousControls>
          </Aads>
          <LDads>
            <umfTarg>0</umfTarg>
            <Ropi>0</Ropi>
            <Rwpi>0</Rwpi>
            <noStLib>0</noStLib>
            <RepFail>1</RepFail>
            <useFile>0</useFile>
            <TextAddressRange>0x08000000</TextAddressRange>
            <DataAddressRange>0x20000000</DataAddressRange>
            <pXoBase></pXoBase>
            <ScatterFile>STM32H743ZI_USB_Audio_Mic.sct</ScatterFile>
            <IncludeLibs></IncludeLibs>
            <IncludeLibsPath></IncludeLibsPath>
            <Misc></Misc>
            <LinkerInputFile></LinkerInputFile>
            <DisabledWarnings></DisabledWarnings>
          </LDads>
        </TargetArmAds>
      </TargetOption>
      <Groups>
{groups_xml}      </Groups>
    </Target>
  </Targets>
</Project>
'''

with open(os.path.join(MDK, "Project.uvprojx"), "w") as f:
    f.write(proj)

# --- uvoptx (canonical) ---
opt = f'''<?xml version="1.0" encoding="UTF-8" standalone="no" ?>
<ProjectOpt xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="project_optx.xsd">
  <SchemaVersion>1.0</SchemaVersion>
  <Header>### uVision Project, (C) Keil Software</Header>
  <Target>
    <TargetName>STM32H743ZI_USB_Audio_Mic</TargetName>
    <ToolsetName>ARM-ADS</ToolsetName>
    <DebugOpt>
      <uSim>0</uSim>
      <uTrg>1</uTrg>
      <sLrtime>0</sLrtime>
      <bEvRecOn>1</bEvRecOn>
      <bSchkAxf>0</bSchkAxf>
      <bTchkAxf>0</bTchkAxf>
      <nTsel>7</nTsel>
      <sDll></sDll>
      <sDllPa></sDllPa>
      <sDlgDll></sDlgDll>
      <sDlgPa></sDlgPa>
      <sIfile></sIfile>
      <tDll></tDll>
      <tDllPa></tDllPa>
      <tDlgDll></tDlgDll>
      <tDlgPa></tDlgPa>
      <tIfile></tIfile>
      <pMon></pMon>
    </DebugOpt>
    <TargetDriverDllOption>
      <SetRegEntry>
        <Number>0</Number>
        <Key>DLGUARM</Key>
        <Name></Name>
      </SetRegEntry>
    </TargetDriverDllOption>
    <TargetOption>
      <FlaClock>240000000</FlaClock>
      <FlaChipOpt>0</FlaChipOpt>
      <FlaDualBank>0</FlaDualBank>
      <FlaZeromode>0</FlaZeromode>
      <FlaMode>0</FlaMode>
      <FlaEraseTime>0</FlaEraseTime>
      <FlaPrgTime>1</FlaPrgTime>
      <FlaPageSize>0</FlaPageSize>
      <FlaBusWidth>0</FlaBusWidth>
      <FlaU2P>0</FlaU2P>
    </TargetOption>
    <MicroMMI_INI></MicroMMI_INI>
  </Target>
  <Project>
    <OutputName>STM32H743ZI_USB_Audio_Mic</OutputName>
  </Project>
</ProjectOpt>
'''

with open(os.path.join(MDK, "Project.uvoptx"), "w") as f:
    f.write(opt)

print(f"Generated Project.uvprojx ({total_files} files in {len(groups)} groups)")
print(f"Generated Project.uvoptx")
print(f"Defines: {defines}")
