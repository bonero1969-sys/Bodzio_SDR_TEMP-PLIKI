# STM32H743ZI — mikrofon USB Audio (UAC 1.0) z X-CUBE-USB-AUDIO

Gotowy projekt Keil MDK-ARM dla płytki Nucleo-H743ZI / Nucleo-H743ZI2, który
uruchamia urządzenie jako mikrofon USB Audio Class 1.0 (48 kHz, stereo, 16-bit)
i wysyła do PC ton sinusoidalny 1 kHz przez złącze USB OTG Full-Speed.

Projekt oparto na referencyjnym przykładzie **UAC10-REC** z pakietu
[X-CUBE-USB-AUDIO](https://www.st.com/en/embedded-software/x-cube-usb-audio.html)
dla STM32F769I-DISCO i przeniesiono na STM32H743ZI (rdzeń Cortex-M7, OTG FS z
wbudowanym PHY, zegar z PLL3). Warstwa middleware X-CUBE (klasa AUDIO_10,
biblioteka USB Device Core, warstwa Streaming) oraz sterowniki HAL/CMSIS dla
STM32H7 zostały dołączone (vendorowane) bezpośrednio do projektu — nie wymaga
instalacji pakietu X-CUBE w CubeMX.

## Status projektu

- Projekt **nie był testowany na sprzęcie** (brak możliwości kompilacji w Keil
  w tym środowisku). Został jednak skonstruowany tak, aby:
  - wszystkie ścieżki plików w `.uvprojx` wskazywały na istniejące pliki (28 plików),
  - pliki `.uvprojx` / `.uvoptx` są poprawnym XML-em (struktura kanoniczna z
    `TargetArmAds`, zgodna z projektami CubeMX),
  - `stm32h7xx_hal_conf.h` włącza tylko niezbędne moduły HAL (RCC, GPIO, DMA,
    MDMA, CORTEX, PWR, FLASH, HSEM, PCD) — brak `HAL_RCC_MODULE_ENABLED`
    i brak `#include "stm32h7xx_hal_flash.h"` były przyczyną błędów typu
    `RCC_ClkInitTypeDef undefined` / `FLASH_LATENCY_5 undefined`,
  - deskryptory USB Audio mają spójne stałe (częstotliwość 48 kHz = bajty
    `0x80 0xBB 0x00`, rozmiar pakietu 192 B = 48 ramek stereo 16-bit,
    topologia: Input Terminal „Microphone" `0x0201` → Output Terminal „USB
    Streaming" `0x0101`).
- Czas kompilacji drastycznie skrócony: w budowie jest tylko 14 plików HAL
  (zamiast ~125) oraz skonsolidowany stos USB w jednym pliku `usb.c`.
- Po otwarciu w Keil może wymagać drobnych poprawek wynikających z wersji
  pakietu urządzenia (DFP) i kompilatora — patrz sekcja „Rozwiązywanie problemów".

## Wymagania

- Płytka Nucleo-H743ZI lub Nucleo-H743ZI2 (HSE 8 MHz, USB OTG FS na PA11/PA12).
- Keil MDK-ARM v5.30+ z pakietem **Keil.STM32H7xx_DFP** (Family Pack dla H7).
- Kabel USB podłączony do złącza USB użytkownika (micro-USB CN13 na Nucleo),
  **nie** do złącza ST-LINK (CN1).

## Struktura projektu

```
STM32H743ZI_USB_Audio_Mic/
├── Application/
│   ├── Inc/   – konfiguracja aplikacji (hal_conf, usbd_conf, usb_audio_*, main.h…)
│   └── Src/   – main.c, usbd_conf.c, usbd_desc.c, stm32h7xx_it.c,
│               stm32h7xx_hal_msp.c, audio_sine_source.c (generator tonu DDS)
├── Drivers/
│   ├── STM32H7xx_HAL_Driver/   – sterownik HAL (tylko 14 plików .c: HAL, RCC,
│   │   PWR, GPIO, DMA, MDMA, HSEM, CORTEX, PCD, USB LL) + nagłówki
│   └── CMSIS/                  – Core + Device (stm32h743xx.h, system, startup)
├── Middlewares/ST/
│   ├── USB_Stack/              – usb.c / usb.h (skonsolidowany stos USB:
│   │   Core + klasa AUDIO 1.0 w jednym pliku)
│   ├── STM32_USB_Device_Library/  – nagłówki Core + Class/AUDIO_10
│   └── AUDIO_Streaming/           – węzły/sesje/deskryptory X-CUBE (nagrywanie)
├── MDK-ARM/
│   ├── Project.uvprojx / .uvoptx  – pliki projektu Keil
│   ├── STM32H743ZI_USB_Audio_Mic.sct – scatter (Flash 0x08000000/2 MB, DTCM 128 KB)
│   ├── startup_stm32h743xx.s      – ten sam plik startowy obejmuje H743ZI/VI (ta sama krzem)
│   └── gen_project.py            – skrypt regenerujący .uvprojx/.uvoptx
└── README.md
```

## Konfiguracja sprzętowa / zegary

- **HSE**: 25 MHz (kwarc płytki STM32H743VIT).
- **SYSCLK**: 240 MHz przez PLL1 (M=25, N=480, P=2 → 25/25=1 MHz × 480 = 480 MHz VCO / 2). Skalowanie napięcia VOS1.
- **USB 48 MHz**: z PLL3Q (M=25, N=240, Q=5 → 1 MHz × 240 = 240 MHz VCO / 5 = 48 MHz),
  wybrane jako źródło zegara USB (`RCC_USBCLKSOURCE_PLL3`). PLL3 dzieli wspólne
  źródło wejściowe PLL (HSE) ustawione przez PLL1 — w tej wersji HAL struktura PLL3
  nie ma pól `PLL3State`/`PLL3Source`; VCO input 1 MHz → `RCC_PLL3VCIRANGE_0`,
  VCO 240 MHz → `RCC_PLL3VCOWIDE`.
- **USB**: OTG Full-Speed, wbudowane PHY, piny PA11 (D-) / PA12 (D+), przerwanie
  `OTG_FS_IRQn` o priorytecie 3.
- **Flash latency**: `FLASH_LATENCY_5` (bezpieczny margines dla 240 MHz @ VOS1;
  nadmiarowe stany oczekiwania są zawsze poprawne, obniżają tylko wydajność).
- **D-Cache**: celowo wyłączony (transfery USB w trybie PIO — bez obsługi cache).

> Uwaga: iniekcja tonu przez `AUDIO_SineFill` w `audio_usb_nodes.c` to ścieżka
> demonstracyjna (na żądanie hosta), a nie standardowa ścieżka producenta
> bufora sesji. Dla prawdziwego źródła audio należy ją usunąć i zastąpić
> dummy mic własnym węzłem.

## Jak działa generator tonu

Pakiet X-CUBE używa architektury „węzeł mikrofonu → bufor kołowy → węzeł USB
OUT". Referencyjny węzeł mikrofonu dla F769 korzystał z kodeka audio przez BSP
(DFSDM/DMA). W tym projekcie zastosowano uproszczony węzeł **dummy mic**
(`USE_AUDIO_DUMMY_MIC=1`), który nie produkuje danych — bufor pozostaje pusty.

Ton generowany jest **na żądanie** w ścieżce pakietów IN: w pliku
`Middlewares/ST/AUDIO_Streaming/Src/audio_usb_nodes.c`, w funkcji
`USB_AudioStreamingOutputGetBuffer`, w miejscach gdzie urządzenie wysyłałoby
pakiet alternatywny (zera — gdy bufor nie jest gotowy lub występuje underrun),
wywoływana jest funkcja `AUDIO_SineFill()` z `audio_sine_source.c`. Funkcja ta
generuje kolejną paczkę 192 B (48 ramek stereo 16-bit) tonu 1 kHz metodą DDS
(akumulator fazy 32-bit + tablica sinus 256 wpisów). Dzięki temu PC słyszy
ciągły ton — bez timera, bez DMA, bez zewnętrznego sprzętu audio.

Aby podłączyć prawdziwe źródło audio (I2S/SAI/ADC przez DMA), należy zastąpić
dummy mic własnym węzłem zapisującym próbki do bufora kołowego (szablon:
`audio_mic_node_template.c`) i usunąć wstrzyknięcie `AUDIO_SineFill` z
`audio_usb_nodes.c`.

## Definicje preprocesora (Keil)

```
USE_HAL_DRIVER, STM32H743xx, USE_USB_FS,
USE_USB_AUDIO_CLASS_10=1,
USE_USB_AUDIO_RECORDING=1, USE_USB_AUDIO_PLAYBACK=0,
USE_AUDIO_DUMMY_MIC=1
```

## Kompilacja i wgranie

1. Otwórz `MDK-ARM/Project.uvprojx` w Keil.
2. Wybierz target `STM32H743ZI_USB_Audio_Mic`.
3. Build (F7). Powinien powstać plik `.axf` / `.hex`.
4. Wgraj do pamięci Flash (F8) przez ST-LINK.
5. Podłącz kabel USB do złącza użytkownika (OTG FS). W Menedżerze urządzeń
   Windows / na liście `arecord -l` (Linux) powinien pojawić się urządzenie
   audio „STM32 AUDIO Streaming". Nagranie (np. Audacity, 48 kHz stereo) powinno
   zawierać ton 1 kHz.

## Rozwiązywanie problemów

- **Brak urządzenia audio po podłączeniu USB**: sprawdź, że kabel jest w
  złączu OTG FS (CN13), a nie ST-LINK. Sprawdź, czy PA11/PA12 są wolne
  (odłączyć ew. peryferia na tych pinach). Sprawdź zegar 48 MHz z PLL3.
- **Brak dźwięku (tylko cisza)**: upewnij się, że host nagrał w trybie 48 kHz /
  stereo / 16-bit i że alt setting 1 jest aktywny (host zaczął strumieniować).
- **Błędy kompilacji z HAL**: wszystkie moduły HAL są włączone w
  `stm32h7xx_hal_conf.h`; jeśli pojedynczy moduł powoduje problemy, można
  wyłączyć jego `#define HAL_..._MODULE_ENABLED` (poza RCC, GPIO, DMA, CORTEX,
  PCD, PWR, FLASH, TIM, EXTI — tych nie wyłączaj).
- **Konflikt symboli `HAL_MspInit`**: projekt zawiera własny
  `stm32h7xx_hal_msp.c`; plik `stm32h7xx_hal_msp_template.c` jest celowo
  pominięty w buildzie.
- **Wersja kompilatora**: projekt skonfigurowano pod ARMCC v5 (AC5). W Keil z
  domyślnym AC6 (Clang) przełącz target na AC5 w Options → Target, albo
  dostosuj opcje AC6. Middleware to czysty C — kompiluje się pod obydwoma.
- **Pakiet urządzenia**: w `.uvprojx` wskazano `Keil.STM32H7xx_DFP`. Jeśli Keil
  nie znajdzie dokładnej wersji zadeklarowanej w pliku, poprosi o wybór
  zainstalowanego pakietu STM32H7xx_DFP — potwierdź wybór (dowolna wersja DFP
  dla H7 działa).
- **Ostrzeżenia kompilatora**: nie są traktowane jako błędy (`Strict=0`).
