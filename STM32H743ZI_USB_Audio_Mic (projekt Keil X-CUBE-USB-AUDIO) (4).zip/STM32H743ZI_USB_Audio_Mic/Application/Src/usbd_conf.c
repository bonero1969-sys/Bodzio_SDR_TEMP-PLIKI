/**
  ******************************************************************************
  * @file    usbd_conf.c
  * @brief   USB Device library callbacks and PCD MSP for STM32H743ZI.
  *          Ported from X-CUBE-USB-AUDIO (STM32F769). STM32H743 has a single
  *          USB OTG Full-Speed instance (USB2_OTG_FS) with embedded PHY.
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_audio.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
PCD_HandleTypeDef hpcd;

/* Private function prototypes -----------------------------------------------*/
static USBD_StatusTypeDef USBD_LL_Setup_Fifo(void);
/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
                       PCD BSP Routines
*******************************************************************************/

/**
  * @brief  Initializes the PCD MSP (USB OTG Full-Speed, embedded PHY).
  *         Pins: PA11 (D-), PA12 (D+), AF10. VBUS sense on PA9, ID on PA10.
  */
void HAL_PCD_MspInit(PCD_HandleTypeDef *hpcd)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  if (hpcd->Instance == USB_OTG_FS)
  {
    __HAL_RCC_GPIOA_CLK_ENABLE();

    /* DM / DP pins */
    GPIO_InitStruct.Pin = GPIO_PIN_11 | GPIO_PIN_12;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF10_OTG2_FS;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* VBUS pin (input) */
    GPIO_InitStruct.Pin = GPIO_PIN_9;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Alternate = 0;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* ID pin (alternate function, open-drain) */
    GPIO_InitStruct.Pin = GPIO_PIN_10;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Alternate = GPIO_AF10_OTG2_FS;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* Enable USB OTG FS clock */
    __HAL_RCC_USB2_OTG_FS_CLK_ENABLE();

    /* USB FS interrupt */
    HAL_NVIC_SetPriority(OTG_FS_IRQn, USB_IRQ_PREPRIO, 0);
    HAL_NVIC_EnableIRQ(OTG_FS_IRQn);
  }
}

void HAL_PCD_MspDeInit(PCD_HandleTypeDef *hpcd)
{
  if (hpcd->Instance == USB_OTG_FS)
  {
    __HAL_RCC_USB2_OTG_FS_CLK_DISABLE();
  }
}

/*******************************************************************************
                       LL Driver Callbacks (PCD -> USB Device Library)
*******************************************************************************/
void HAL_PCD_SetupStageCallback(PCD_HandleTypeDef *hpcd)
{
  USBD_LL_SetupStage(hpcd->pData, (uint8_t *)hpcd->Setup);
}

void HAL_PCD_DataOutStageCallback(PCD_HandleTypeDef *hpcd, uint8_t epnum)
{
  USBD_LL_DataOutStage(hpcd->pData, epnum, hpcd->OUT_ep[epnum].xfer_buff);
}

void HAL_PCD_DataInStageCallback(PCD_HandleTypeDef *hpcd, uint8_t epnum)
{
  USBD_LL_DataInStage(hpcd->pData, epnum, hpcd->IN_ep[epnum].xfer_buff);
}

void HAL_PCD_SOFCallback(PCD_HandleTypeDef *hpcd)
{
  USBD_LL_SOF(hpcd->pData);
}

void HAL_PCD_ResetCallback(PCD_HandleTypeDef *hpcd)
{
  USBD_SpeedTypeDef speed = USBD_SPEED_FULL;

  switch (hpcd->Init.speed)
  {
  case PCD_SPEED_HIGH:
    speed = USBD_SPEED_HIGH;
    break;
  case PCD_SPEED_FULL:
    speed = USBD_SPEED_FULL;
    break;
  default:
    speed = USBD_SPEED_FULL;
    break;
  }

  USBD_LL_Reset(hpcd->pData);
  USBD_LL_SetSpeed(hpcd->pData, speed);
}

void HAL_PCD_SuspendCallback(PCD_HandleTypeDef *hpcd)
{
  USBD_LL_Suspend(hpcd->pData);
}

void HAL_PCD_ResumeCallback(PCD_HandleTypeDef *hpcd)
{
  USBD_LL_Resume(hpcd->pData);
}

void HAL_PCD_ISOOUTIncompleteCallback(PCD_HandleTypeDef *hpcd, uint8_t epnum)
{
  USBD_LL_IsoOUTIncomplete(hpcd->pData, epnum);
}

void HAL_PCD_ISOINIncompleteCallback(PCD_HandleTypeDef *hpcd, uint8_t epnum)
{
  USBD_LL_IsoINIncomplete(hpcd->pData, epnum);
}

void HAL_PCD_ConnectCallback(PCD_HandleTypeDef *hpcd)
{
  USBD_LL_DevConnected(hpcd->pData);
}

void HAL_PCD_DisconnectCallback(PCD_HandleTypeDef *hpcd)
{
  USBD_LL_DevDisconnected(hpcd->pData);
}

/*******************************************************************************
                       LL Driver Interface (USB Device Library --> PCD)
*******************************************************************************/
USBD_StatusTypeDef USBD_LL_Init(USBD_HandleTypeDef *pdev)
{
#ifdef USE_USB_FS
  /* Set LL Driver parameters */
  hpcd.Instance = USB_OTG_FS;
  hpcd.Init.dev_endpoints = 4;
  hpcd.Init.use_dedicated_ep1 = 0;
  hpcd.Init.ep0_mps = 0x40;
  hpcd.Init.dma_enable = 0;
  hpcd.Init.low_power_enable = 0;
  hpcd.Init.phy_itface = PCD_PHY_EMBEDDED;
  hpcd.Init.Sof_enable = 1;
  hpcd.Init.speed = PCD_SPEED_FULL;
  hpcd.Init.vbus_sensing_enable = 1;
  hpcd.Init.lpm_enable = 0;

  /* Link the driver to the stack */
  hpcd.pData = pdev;
  pdev->pData = &hpcd;

  /* Initialize LL Driver */
  HAL_PCD_Init(&hpcd);
  USBD_LL_Setup_Fifo();
#else
  #error "This project requires USE_USB_FS to be defined."
#endif
  return USBD_OK;
}

USBD_StatusTypeDef USBD_LL_DeInit(USBD_HandleTypeDef *pdev)
{
  HAL_PCD_DeInit(pdev->pData);
  return USBD_OK;
}

USBD_StatusTypeDef USBD_LL_Start(USBD_HandleTypeDef *pdev)
{
  HAL_PCD_Start(pdev->pData);
  return USBD_OK;
}

USBD_StatusTypeDef USBD_LL_Stop(USBD_HandleTypeDef *pdev)
{
  HAL_PCD_Stop(pdev->pData);
  return USBD_OK;
}

USBD_StatusTypeDef USBD_LL_OpenEP(USBD_HandleTypeDef *pdev,
                                  uint8_t ep_addr,
                                  uint8_t ep_type,
                                  uint16_t ep_mps)
{
  HAL_PCD_EP_Open(pdev->pData, ep_addr, ep_mps, ep_type);
  return USBD_OK;
}

USBD_StatusTypeDef USBD_LL_CloseEP(USBD_HandleTypeDef *pdev, uint8_t ep_addr)
{
  USB_DISABLE_EP_BEFORE_CLOSE(ep_addr);
  HAL_PCD_EP_Close(pdev->pData, ep_addr);
  return USBD_OK;
}

USBD_StatusTypeDef USBD_LL_FlushEP(USBD_HandleTypeDef *pdev, uint8_t ep_addr)
{
  HAL_PCD_EP_Flush(pdev->pData, ep_addr);
  return USBD_OK;
}

USBD_StatusTypeDef USBD_LL_StallEP(USBD_HandleTypeDef *pdev, uint8_t ep_addr)
{
  HAL_PCD_EP_SetStall(pdev->pData, ep_addr);
  return USBD_OK;
}

USBD_StatusTypeDef USBD_LL_ClearStallEP(USBD_HandleTypeDef *pdev, uint8_t ep_addr)
{
  HAL_PCD_EP_ClrStall(pdev->pData, ep_addr);
  return USBD_OK;
}

uint8_t USBD_LL_IsStallEP(USBD_HandleTypeDef *pdev, uint8_t ep_addr)
{
  PCD_HandleTypeDef *hpcd = pdev->pData;

  if ((ep_addr & 0x80) == 0x80)
    return hpcd->IN_ep[ep_addr & 0x7F].is_stall;
  else
    return hpcd->OUT_ep[ep_addr & 0x7F].is_stall;
}

USBD_StatusTypeDef USBD_LL_SetUSBAddress(USBD_HandleTypeDef *pdev, uint8_t dev_addr)
{
  HAL_PCD_SetAddress(pdev->pData, dev_addr);
  return USBD_OK;
}

USBD_StatusTypeDef USBD_LL_Transmit(USBD_HandleTypeDef *pdev,
                                    uint8_t ep_addr,
                                    uint8_t *pbuf,
                                    uint16_t size)
{
  HAL_PCD_EP_Transmit(pdev->pData, ep_addr, pbuf, size);
  return USBD_OK;
}

USBD_StatusTypeDef USBD_LL_PrepareReceive(USBD_HandleTypeDef *pdev,
                                          uint8_t ep_addr,
                                          uint8_t *pbuf,
                                          uint16_t size)
{
  HAL_PCD_EP_Receive(pdev->pData, ep_addr, pbuf, size);
  return USBD_OK;
}

uint32_t USBD_LL_GetRxDataSize(USBD_HandleTypeDef *pdev, uint8_t ep_addr)
{
  return HAL_PCD_EP_GetRxCount(pdev->pData, ep_addr);
}

void USBD_LL_Delay(uint32_t Delay)
{
  HAL_Delay(Delay);
}

/**
  * @brief  Setup dynamically the USB FIFOs (RX + TX).
  *         For Full-Speed only (recording path): one IN isochronous endpoint.
  */
static USBD_StatusTypeDef USBD_LL_Setup_Fifo(void)
{
  uint16_t tx_fifo_size[5] = {0};
  uint8_t max_tx_ep_num = 0;
  uint16_t tx_fifo_used_size = 0;
  uint16_t rx_fifo_size = 0;

#if USE_USB_AUDIO_PLAYBACK
  rx_fifo_size = (USBD_AUDIO_CONFIG_PLAY_MAX_PACKET_SIZE > 64) ? (USBD_AUDIO_CONFIG_PLAY_MAX_PACKET_SIZE + 3U) / 4 : 16;
#else
  rx_fifo_size = 16; /* 64 / 4 */
#endif

#if USE_USB_AUDIO_RECORDING
  if ((USB_AUDIO_CONFIG_RECORD_EP_IN & 0x7F) > max_tx_ep_num)
  {
    max_tx_ep_num = USB_AUDIO_CONFIG_RECORD_EP_IN & 0x7F;
  }
  tx_fifo_size[USB_AUDIO_CONFIG_RECORD_EP_IN & 0x7F] = (USBD_AUDIO_CONFIG_RECORD_MAX_PACKET_SIZE + 3U) / 4;
#endif

  tx_fifo_used_size = (USB_AUDIO_GetConfigDescriptor(0) + 3) / 4;
  tx_fifo_size[0] = tx_fifo_used_size;

  for (int i = 1; i <= max_tx_ep_num; i++)
  {
    if (tx_fifo_size[i] < 16)
      tx_fifo_size[i] = 16;
    tx_fifo_used_size += tx_fifo_size[i];
  }

  rx_fifo_size += (5 * 1 + 8 + 1 + 2 * 8 + 1);

  if (tx_fifo_used_size + rx_fifo_size <= USB_FIFO_WORD_SIZE)
  {
#if USE_USB_AUDIO_RECORDING
    tx_fifo_size[USB_AUDIO_CONFIG_RECORD_EP_IN & 0x7F] += USB_FIFO_WORD_SIZE - (tx_fifo_used_size + rx_fifo_size);
#else
#if USE_USB_AUDIO_PLAYBACK
    rx_fifo_size = USB_FIFO_WORD_SIZE - tx_fifo_used_size;
#endif
#endif
  }
  else
  {
    Error_Handler();
  }

  HAL_PCDEx_SetRxFiFo(&hpcd, rx_fifo_size);
  for (int i = 0; i <= max_tx_ep_num; i++)
  {
    HAL_PCDEx_SetTxFiFo(&hpcd, i, tx_fifo_size[i]);
  }
  return USBD_OK;
}

/* USB Audio class error callback — invoked by the AUDIO 1.0 driver on fatal
 * descriptor/state errors. Route to the common Error_Handler. */
void USBD_error_handler(void)
{
  Error_Handler();
}
