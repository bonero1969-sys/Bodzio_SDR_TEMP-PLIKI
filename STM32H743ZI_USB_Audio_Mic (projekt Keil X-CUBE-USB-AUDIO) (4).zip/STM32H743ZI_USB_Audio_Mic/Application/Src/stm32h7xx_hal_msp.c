/**
  ******************************************************************************
  * @file    stm32h7xx_hal_msp.c
  * @brief   HAL MSP module (STM32H743ZI). USB OTG FS MSP initialization is
  *          performed in usbd_conf.c (HAL_PCD_MspInit). This file keeps a
  *          global HAL_MspInit placeholder.
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

void HAL_MspInit(void)
{
  /* Global MSP init - nothing required for this demo */
}
