/**
  ******************************************************************************
  * @file    main.c
  * @brief   USB Audio Class 1.0 microphone demo for STM32H743ZI.
  *
  *          The device enumerates as a USB microphone (48 kHz / stereo /
  *          16-bit) and streams a 1 kHz sine tone to the PC. Based on the
  *          X-CUBE-USB-AUDIO UAC10-REC example ported from STM32F769I-DISCO
  *          to STM32H743ZI (USB OTG Full-Speed, embedded PHY).
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
USBD_HandleTypeDef USBD_Device;

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Config(void);
static void CPU_CACHE_Enable(void);
void Error_Handler(void);            /* exported for usbd_conf.c / USB stack */

/* Exported variables --------------------------------------------------------*/
/* (USB PCD handle hpcd is defined in usbd_conf.c) */

/* Body ---------------------------------------------------------------------*/
int main(void)
{
  /* MPU configuration (optional, leave default for this demo) */

  /* Enable CPU caches (I-Cache on; D-Cache left OFF to keep USB PIO buffers
   * coherent without manual cache maintenance). */
  CPU_CACHE_Enable();

  /* HAL Init */
  HAL_Init();

  /* System clock: 240 MHz, USB 48 MHz from PLL3Q */
  SystemClock_Config();

  /* Initialize USB Device Library, register AUDIO class and start */
  USBD_Init(&USBD_Device, &AUDIO_Desc, 0);
  USBD_RegisterClass(&USBD_Device, USBD_AUDIO_CLASS);
  USBD_AUDIO_RegisterInterface(&USBD_Device, &audio_class_interface);
  USBD_Start(&USBD_Device);

  /* Main loop - everything is driven by USB interrupts */
  while (1)
  {
  }
}

/**
  * @brief  System Clock Configuration for STM32H743VIT.
  *         HSE = 25 MHz (board crystal).
  *         SYSCLK = 240 MHz via PLL1 (M=25, N=480, P=2).
  *         USB 48 MHz clock from PLL3Q (M=25, N=240, Q=5).
  *         AHB/APB dividers set for 240/120/60 MHz.
  *         Note: PLL1/2/3 share the PLL input source (HSE, set by PLL1 config),
  *         so PLL3 does not need a separate source field in this HAL version.
  */
static void SystemClock_Config(void)
{
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

  /* Supply configuration: enable LDO regulator for VOS1 (240 MHz) */
  HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /* HSE 25 MHz */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSIState = RCC_HSI_OFF;
  RCC_OscInitStruct.CSIState = RCC_CSI_OFF;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;             /* 25/25 = 1 MHz VCO input */
  RCC_OscInitStruct.PLL.PLLN = 480;            /* 1*480 = 480 MHz VCO */
  RCC_OscInitStruct.PLL.PLLP = 2;              /* 480/2 = 240 MHz SYSCLK */
  RCC_OscInitStruct.PLL.PLLQ = 20;             /* unused */
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /* PLL3 for USB: 25/25=1 MHz input * 240 = 240 MHz VCO / Q5 = 48 MHz on PLL3Q.
   * PLL3 source = HSE (shared PLL input source, set by PLL1 config above).
   * VCO input 1 MHz -> VCIRANGE_0 (1-2 MHz); VCO 240 MHz -> VCOWIDE (128-560). */
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_USB;
  PeriphClkInitStruct.PLL3.PLL3M = 25;
  PeriphClkInitStruct.PLL3.PLL3N = 240;
  PeriphClkInitStruct.PLL3.PLL3P = 2;
  PeriphClkInitStruct.PLL3.PLL3Q = 5;             /* 240 MHz / 5 = 48 MHz */
  PeriphClkInitStruct.PLL3.PLL3R = 2;
  PeriphClkInitStruct.PLL3.PLL3RGE = RCC_PLL3VCIRANGE_0;
  PeriphClkInitStruct.PLL3.PLL3VCOSEL = RCC_PLL3VCOWIDE;
  PeriphClkInitStruct.PLL3.PLL3FRACN = 0;
  PeriphClkInitStruct.UsbClockSelection = RCC_USBCLKSOURCE_PLL3;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /* Flash latency for 240 MHz (VOS1) */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                              | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2
                              | RCC_CLOCKTYPE_D3PCLK1 | RCC_CLOCKTYPE_D1PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.SYSCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_APB3_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_APB2_DIV2;
  RCC_ClkInitStruct.APB4CLKDivider = RCC_APB4_DIV2;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief  Enable I-Cache. D-Cache is intentionally left disabled to keep
  *         USB PIO transfers coherent without cache maintenance.
  */
static void CPU_CACHE_Enable(void)
{
  SCB_EnableICache();
  /* D-Cache disabled on purpose */
}

void Error_Handler(void)
{
  while (1)
  {
  }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  while (1)
  {
  }
}
#endif
