/**
  ******************************************************************************
  * @file    audio_sine_source.h
  * @brief   On-demand DDS sine-tone generator for the USB audio microphone
  *          demo. Produces a continuous 1 kHz stereo 16-bit tone, generated
  *          sample-by-sample each time the USB Audio class asks for the next
  *          IN packet (once per 1 ms SOF). No timer, no DMA, no external
  *          hardware required.
  ******************************************************************************
  */
#ifndef __AUDIO_SINE_SOURCE_H
#define __AUDIO_SINE_SOURCE_H

#ifdef __cplusplus
 extern "C" {
#endif

#include <stdint.h>

/**
 * @brief  Fill a USB IN packet buffer with the next chunk of sine samples.
 * @param  dst:  destination buffer (must hold at least `len` bytes)
 * @param  len:  number of bytes to generate. Must be a multiple of
 *               (channels * bytes_per_sample). For 48 kHz / stereo / 16-bit
 *               this is 192 bytes = 48 sample frames per 1 ms.
 * @note   A persistent phase accumulator is kept internally so successive
 *         calls produce a continuous waveform.
 */
void AUDIO_SineFill(uint8_t *dst, uint16_t len);

#ifdef __cplusplus
}
#endif

#endif /* __AUDIO_SINE_SOURCE_H */
