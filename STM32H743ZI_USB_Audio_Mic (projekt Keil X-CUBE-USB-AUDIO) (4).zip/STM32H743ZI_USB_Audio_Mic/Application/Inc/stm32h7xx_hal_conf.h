/**
  ******************************************************************************
  * @file    stm32h7xx_hal_conf.h
  * @brief   HAL configuration for STM32H743ZI USB Audio microphone demo.
  *          Only modules required for USB OTG FS audio are enabled, to keep
  *          compile time and code size minimal.
  ******************************************************************************
  */
#ifndef __STM32H7xx_HAL_CONF_H
#define __STM32H7xx_HAL_CONF_H

#ifdef __cplusplus
 extern "C" {
#endif

/* ########################## Module Selection ############################## */
/* Only the modules actually used by this project are enabled. */
#define HAL_MODULE_ENABLED
#define HAL_RCC_MODULE_ENABLED
#define HAL_GPIO_MODULE_ENABLED
#define HAL_DMA_MODULE_ENABLED
#define HAL_MDMA_MODULE_ENABLED
#define HAL_CORTEX_MODULE_ENABLED
#define HAL_PWR_MODULE_ENABLED
#define HAL_FLASH_MODULE_ENABLED      /* FLASH_LATENCY_x macros for clock config */
#define HAL_HSEM_MODULE_ENABLED       /* USB OTG clock config lock */
#define HAL_PCD_MODULE_ENABLED        /* USB peripheral controller */

/* ########################## Oscillator Values adaptation ####################*/
#define HSE_VALUE    ((uint32_t)8000000)   /*!< Value of the HSE in Hz (Nucleo-H743ZI2: 8 MHz) */
#define HSE_STARTUP_TIMEOUT ((uint32_t)5000)
#define CSI_VALUE    ((uint32_t)4000000)
#define HSI_VALUE    ((uint32_t)64000000)
#define LSI_VALUE    ((uint32_t)32000)
#define LSE_VALUE    ((uint32_t)32768)
#define LSE_STARTUP_TIMEOUT ((uint32_t)5000)

#define EXTERNAL_CLOCK_VALUE ((uint32_t)12288000)

/* ########################### System Configuration ######################### */
#define VDD_VALUE                    ((uint32_t)3300)
#define TICK_INT_PRIORITY            ((uint32_t)0x0F)
#define USE_RTOS                     0
#define USE_HAL_DRIVER
#define USE_SPI_CRC                   0
#define USE_HAL_PCD_REGISTER_CALLBACKS         0

/* ########################## Assert Selection ############################## */
#define USE_FULL_ASSERT    0

/* Includes ------------------------------------------------------------------*/
#ifdef HAL_RCC_MODULE_ENABLED
 #include "stm32h7xx_hal_rcc.h"
#endif
#ifdef HAL_GPIO_MODULE_ENABLED
 #include "stm32h7xx_hal_gpio.h"
#endif
#ifdef HAL_DMA_MODULE_ENABLED
 #include "stm32h7xx_hal_dma.h"
#endif
#ifdef HAL_MDMA_MODULE_ENABLED
 #include "stm32h7xx_hal_mdma.h"
#endif
#ifdef HAL_CORTEX_MODULE_ENABLED
 #include "stm32h7xx_hal_cortex.h"
#endif
#ifdef HAL_PWR_MODULE_ENABLED
 #include "stm32h7xx_hal_pwr.h"
#endif
#ifdef HAL_FLASH_MODULE_ENABLED
 #include "stm32h7xx_hal_flash.h"
#endif
#ifdef HAL_HSEM_MODULE_ENABLED
 #include "stm32h7xx_hal_hsem.h"
#endif
#ifdef HAL_PCD_MODULE_ENABLED
 #include "stm32h7xx_hal_pcd.h"
#endif

/* Exported macro ------------------------------------------------------------*/
#ifdef USE_FULL_ASSERT
 #define assert_param(expr) ((expr) ? (void)0 : assert_failed((uint8_t *)__FILE__, __LINE__))
 void assert_failed(uint8_t *file, uint32_t line);
#else
 #define assert_param(expr) ((void)0)
#endif

#ifdef __cplusplus
}
#endif

#endif /* __STM32H7xx_HAL_CONF_H */
