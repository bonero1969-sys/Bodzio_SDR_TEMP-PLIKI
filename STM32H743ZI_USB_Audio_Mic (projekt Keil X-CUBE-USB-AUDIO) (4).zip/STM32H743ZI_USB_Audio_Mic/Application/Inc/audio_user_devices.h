/**
  ******************************************************************************
  * @file    audio_user_devices.h
  * @brief   Board-specific audio device abstraction (stub).
  *
  *          This demo uses the X-CUBE-USB-AUDIO "dummy mic" node
  *          (USE_AUDIO_DUMMY_MIC) together with an on-demand sine generator,
  *          so no board BSP audio driver is required. This file is kept as a
  *          minimal placeholder; it is not included when USE_AUDIO_DUMMY_MIC
  *          is defined (see audio_mic_node.h).
  ******************************************************************************
  */
#ifndef __AUDIO_USER_DEVICES_H
#define __AUDIO_USER_DEVICES_H

#ifdef __cplusplus
 extern "C" {
#endif

#include "usb_audio.h"

#ifdef __cplusplus
}
#endif

#endif /* __AUDIO_USER_DEVICES_H */
